Ques No. 1
ans - B)  using <link> tag


 
Ques No. 2
ans - B) using p tag




Ques No. 3
ans - B) false 



Ques No. 4
ans - B) false 



Ques No. 5
ans - C) 10000000000 


Ques No. 6
ans -    A) const namesArray = people.map(person => person.name);

B) const salaryArray = people.map(person => ({ ...person, salary: 50000 }))
            
          
        C.  const peopleAbove30 = people
        .filter(person => person.age > 30)
        .map(person => ({ name: person.name, age: person.age }));
      


Ques No. 7
ans - function main(cb1, cb2, x, y) {
    console.log("Sum:", cb1(x, y));
    console.log("Difference:", cb2(x, y));
  }
  
  function add(x, y) {
    return x + y;
  }
  
  function subtract(x, y) {
    return x - y;
  }
  
  const x = 11;
  const y = 4;
  
  main(add, subtract, x, y);

  



Ques No. 8
ans - c)map function



Ques No. 9
ans - 



Ques No. 10
ans - C)  []



Ques No. 11
ans - B)  display : none removes the element from the dom
while visibility : hidden just hides the element.



Ques No. 12
ans - A)  4 10 18



Ques No. 13
ans - A) [1,2,3,4]

